import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter, Route, Routes } from 'react-router-dom'
import './index.css'
import { AppProvider } from './store'
import Layout from './components/Layout'
import Landing from './pages/Landing'
import Workspace from './pages/Workspace'
import Sources from './pages/Sources'
import Dashboard from './pages/Dashboard'
import Compare from './pages/Compare'
import Radar from './pages/Radar'
import Checklist from './pages/Checklist'
import ReportPage from './pages/ReportPage'
import History from './pages/History'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Landing />} />
            <Route path="workspace" element={<Workspace />} />
            <Route path="sources" element={<Sources />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="compare" element={<Compare />} />
            <Route path="radar" element={<Radar />} />
            <Route path="checklist" element={<Checklist />} />
            <Route path="report" element={<ReportPage />} />
            <Route path="history" element={<History />} />
          </Route>
        </Routes>
      </HashRouter>
    </AppProvider>
  </React.StrictMode>,
)
