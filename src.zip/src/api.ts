import type { Draft, Health, Report, SessionRow, Source } from './types'

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? ''

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  let r: Response
  try {
    r = await fetch(BASE + path, init)
  } catch {
    throw new Error('Cannot reach the server. Check that the backend is running and VITE_API_BASE is correct.')
  }
  if (!r.ok) {
    let detail = ''
    try {
      const j = await r.json()
      detail = typeof j.detail === 'string' ? j.detail : j.detail ? 'The request was not valid. Check your inputs.' : ''
    } catch { /* not JSON */ }
    throw new Error(detail || `The server returned an error (${r.status}).`)
  }
  return r.json() as Promise<T>
}
const post = <T,>(path: string, body: unknown) =>
  req<T>(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })

export interface Extracted { sources: Source[]; failures: { url: string; error: string }[] }

export const api = {
  health: () => req<Health>('/api/health'),
  demo: () => req<Draft & { subquestions: string[]; sources: Source[]; notice: string }>('/api/demo'),
  urls: (urls: string[]) => post<Extracted>('/api/extract/urls', { urls }),
  files: (files: File[]) => {
    const fd = new FormData()
    files.forEach((f) => fd.append('files', f))
    return req<Extracted>('/api/extract/files', { method: 'POST', body: fd })
  },
  paste: (b: { title: string; text: string; url?: string; published?: string }) => post<{ source: Source }>('/api/extract/paste', b),
  analyze: (d: Draft, sources: Source[], useAi: boolean) =>
    post<Report>('/api/analyze', {
      topic: d.topic, question: d.question, category: d.category, use_ai: useAi, sources,
      subquestions: d.subquestions.split('\n').map((s) => s.trim()).filter(Boolean),
    }),
  saveSession: (title: string, payload: unknown) => post<SessionRow>('/api/sessions', { title, payload }),
  sessions: () => req<SessionRow[]>('/api/sessions'),
  session: (id: string) => req<{ payload: { draft: Draft; sources: Source[]; report: Report } }>(`/api/sessions/${id}`),
}
