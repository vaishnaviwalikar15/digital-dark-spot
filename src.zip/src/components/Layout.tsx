import { NavLink, Outlet } from 'react-router-dom'
import { useApp } from '../store'

const LINKS: [string, string][] = [['/', 'Home'], ['/workspace', 'Workspace'], ['/sources', 'Sources'], ['/dashboard', 'Dashboard'],
  ['/compare', 'Compare'], ['/radar', 'Gap Radar'], ['/checklist', 'Checklist'], ['/report', 'Report'], ['/history', 'History']]

export default function Layout() {
  const { stale, report } = useApp()
  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-900 to-navy-950">
      <header className="sticky top-0 z-10 border-b border-navy-700 bg-navy-950/95 print:hidden">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4">
          <span className="whitespace-nowrap font-display text-lg text-teal">Digital Dark Spot</span>
          <nav aria-label="Main" className="flex gap-1 overflow-x-auto py-2">
            {LINKS.map(([to, name]) => (
              <NavLink key={to} to={to} end={to === '/'}
                className={({ isActive }) => `whitespace-nowrap rounded-lg px-3 py-1.5 text-sm ${isActive ? 'bg-navy-700 text-white' : 'text-slate-300 hover:bg-navy-800'}`}>
                {name}
              </NavLink>
            ))}
          </nav>
        </div>
        {stale && report && (
          <div className="bg-amber-950/60 px-4 py-1 text-center text-sm text-amber-200">Sources changed since the last analysis. Run it again from the Workspace.</div>
        )}
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6"><Outlet /></main>
    </div>
  )
}
