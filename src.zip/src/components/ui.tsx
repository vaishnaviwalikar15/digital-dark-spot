import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import type { Priority, Status } from '../types'

const STATUS: Record<Status, string> = {
  found: 'border-emerald-400 text-emerald-300', partial: 'border-amber-400 text-amber-300',
  conflict: 'border-rose-400 text-rose-300', missing: 'border-slate-400 text-slate-300',
}
const STATUS_TEXT: Record<Status, string> = { found: 'Found', partial: 'Partial', conflict: 'Conflict', missing: 'Missing' }
export const StatusBadge = ({ s }: { s: Status }) => (
  <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${STATUS[s]}`}>{STATUS_TEXT[s]}</span>
)

const LABEL: Record<string, string> = {
  'Confirmed from source': 'border-emerald-400 text-emerald-300', 'Possible information gap': 'border-amber-400 text-amber-300',
  'Possible conflict': 'border-rose-400 text-rose-300', 'Needs verification': 'border-sky-400 text-sky-300',
  'AI-generated suggestion': 'border-violet-400 text-violet-300',
}
export const LabelBadge = ({ label }: { label: string }) => (
  <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${LABEL[label] ?? 'border-slate-400'}`}>{label}</span>
)
export const Pill = ({ children }: { children: ReactNode }) => (
  <span className="inline-block rounded-full border border-navy-600 px-2.5 py-0.5 text-xs text-slate-300">{children}</span>
)
export const PRIORITY_TEXT: Record<Priority, string> = { high: 'High priority', medium: 'Medium priority', low: 'Low priority' }
export const PRIORITY_COLOR: Record<Priority, string> = { high: 'text-rose-300', medium: 'text-amber-300', low: 'text-slate-300' }

export const Stat = ({ value, label }: { value: number | string; label: string }) => (
  <div className="card">
    <div className="font-display text-3xl text-teal">{value}</div>
    <div className="text-sm text-slate-300">{label}</div>
  </div>
)
export const Spinner = ({ text }: { text: string }) => (
  <div role="status" className="flex items-center gap-3 text-slate-200">
    <span className="h-4 w-4 animate-spin rounded-full border-2 border-teal border-t-transparent" aria-hidden />
    {text}
  </div>
)
export const ErrorBox = ({ children }: { children: ReactNode }) => (
  <div role="alert" className="rounded-lg border border-rose-400 bg-rose-950/40 p-3 text-sm text-rose-100">{children}</div>
)
export const Empty = ({ text, to, cta }: { text: string; to: string; cta: string }) => (
  <div className="card text-center">
    <p className="muted mb-3">{text}</p>
    <Link to={to} className="btn-primary">{cta}</Link>
  </div>
)
