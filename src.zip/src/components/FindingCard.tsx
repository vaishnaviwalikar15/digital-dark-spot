import { Link } from 'react-router-dom'
import type { Finding } from '../types'
import { LabelBadge, Pill, PRIORITY_COLOR, PRIORITY_TEXT } from './ui'

export function FindingCard({ f }: { f: Finding }) {
  return (
    <article className="card space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <LabelBadge label={f.label} />
        <Pill>{f.category}</Pill>
        <span className={`text-xs ${PRIORITY_COLOR[f.priority]}`}>{PRIORITY_TEXT[f.priority]}</span>
        {f.origin === 'ai' && <Pill>From AI, quotes verified</Pill>}
      </div>
      <h3 className="text-lg">{f.title}</h3>
      <p className="muted text-sm">Why flagged: {f.reason}</p>
      <p className="text-xs text-slate-400">Confidence: {f.confidence}</p>
      {f.evidence.length === 0 ? (
        <p className="text-sm text-slate-400">No quoted evidence. This flags something absent from the sources, not something proven absent anywhere.</p>
      ) : (
        f.evidence.map((e, i) => (
          <blockquote key={i} className="border-l-4 border-navy-600 pl-3 text-sm">
            <span className="text-slate-100">“{e.quote}”</span>
            <footer className="mt-1 text-xs text-slate-400">
              <Link className="text-teal underline" to={`/sources?open=${e.source_id}`}>{e.source_title}</Link>
              {e.url && <> · <a className="text-teal underline" href={e.url} target="_blank" rel="noopener noreferrer">open original</a></>}
            </footer>
          </blockquote>
        ))
      )}
    </article>
  )
}
