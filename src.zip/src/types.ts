export type Priority = 'high' | 'medium' | 'low'
export type Status = 'found' | 'partial' | 'conflict' | 'missing'

export interface Source {
  id: string; title: string; url: string | null; domain: string | null
  source_type: 'url' | 'pdf' | 'docx' | 'txt' | 'pasted' | 'demo'
  origin: 'retrieved' | 'user_provided' | 'demo_fictional'
  text: string; published: string | null; updated: string | null; retrieved_at: string
}
export interface Evidence { source_id: string; source_title: string; quote: string; url: string | null }
export interface Finding {
  id: string; title: string; category: string; label: string; evidence: Evidence[]
  confidence: string; reason: string; priority: Priority; origin: 'rule' | 'ai'
}
export interface Cell { source_id: string; value: string | null; quote: string | null; note: string | null }
export interface Row { key: string; label: string; category: string; cells: Cell[]; status: Status }
export interface Coverage {
  category: string; status: Status; score: number; found: number; partial: number; conflict: number; missing: number; items: number
}
export interface Freshness { source_id: string; source_title: string; kind: string; status: string; date_text: string | null; note: string }
export interface Question { question: string; reason: string; origin: string }
export interface ChecklistItem { id: string; text: string; priority: Priority; finding_ids: string[]; done: boolean }
export interface Report {
  question: string; topic?: string; category?: string; generated_at: string
  engine: { rule_based: boolean; ai_requested: boolean; ai_used: boolean; ai_error: string | null; ai_dropped: number; model: string | null }
  sources: Array<Pick<Source, 'id' | 'title' | 'url' | 'domain' | 'source_type' | 'origin' | 'published' | 'updated' | 'retrieved_at'> & { characters: number }>
  findings: Finding[]; comparison: Row[]; coverage: Coverage[]; score: number; score_explanation: string
  freshness: Freshness[]; questions: Question[]; checklist: ChecklistItem[]
  stats: { sources: number; key_facts: number; gaps: number; conflicts: number; freshness_warnings: number; questions: number }
  limitations: string
}
export interface Draft { topic: string; question: string; subquestions: string; category: string }
export interface Health { ok: boolean; ai_configured: boolean; model: string | null; persistence: string }
export interface SessionRow { id: string; title: string; created_at: string }
export const CATEGORIES = ['Education and Scholarships', 'Government Schemes', 'Career and Employment', 'Research and Science', 'Public Services', 'General Research']
