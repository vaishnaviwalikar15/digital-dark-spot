import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useApp } from '../store'
import { CATEGORIES } from '../types'
import { ErrorBox, Spinner } from '../components/ui'

export default function Workspace() {
  const { draft, setDraft, sources, analyze, loadDemo, busy, error, health, notice } = useApp()
  const [useAi, setUseAi] = useState(false)
  const nav = useNavigate()
  const set = (k: keyof typeof draft) => (e: { target: { value: string } }) => setDraft({ ...draft, [k]: e.target.value })
  const ready = draft.question.trim().length >= 3 && sources.length > 0

  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Research workspace</h1>
      {notice && <div className="card text-sm text-amber-200">{notice}</div>}
      <form className="card space-y-4" onSubmit={async (e) => { e.preventDefault(); if (ready && (await analyze(useAi))) nav('/dashboard') }}>
        <div><label htmlFor="topic">Research topic</label><input id="topic" value={draft.topic} onChange={set('topic')} placeholder="e.g. Example Student Grant 2026" /></div>
        <div><label htmlFor="q">Main research question</label>
          <textarea id="q" rows={2} required minLength={3} value={draft.question} onChange={set('question')} placeholder="What should I verify before applying for this scholarship?" /></div>
        <div><label htmlFor="sq">Subquestions (optional, one per line)</label>
          <textarea id="sq" rows={3} value={draft.subquestions} onChange={set('subquestions')} placeholder="Is there an appeal procedure?" /></div>
        <div><label htmlFor="cat">Category</label>
          <select id="cat" value={draft.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div className="rounded-lg border border-navy-700 p-3 text-sm">
          {health?.ai_configured ? (
            <label className="flex items-center gap-2"><input type="checkbox" checked={useAi} onChange={(e) => setUseAi(e.target.checked)} />
              Add Gemini analysis on top of the rule-based checks</label>
          ) : (
            <p className="muted">{health ? 'AI analysis is not configured on this server. The rule-based engine runs on its own.' : 'The server did not answer, so the status of AI analysis is unknown.'}</p>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button className="btn-primary" disabled={!ready || busy} type="submit">Analyze {sources.length} source{sources.length === 1 ? '' : 's'}</button>
          <Link className="btn-ghost" to="/sources">Manage sources</Link>
          <button type="button" className="btn-ghost" disabled={busy} onClick={() => loadDemo()}>Load fictional demo</button>
        </div>
        {!sources.length && <p className="muted text-sm">Add at least one source before analyzing.</p>}
        {busy && <Spinner text="Analyzing sources…" />}
        {error && <ErrorBox>{error}</ErrorBox>}
      </form>
    </div>
  )
}
