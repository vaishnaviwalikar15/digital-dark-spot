import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../store'
import { ErrorBox, Spinner } from '../components/ui'

const FEATURES = [
  ['Information gaps', 'Details that none of your sources mention, such as renewal rules or required documents.'],
  ['Conflicts', 'Claims that differ between sources, shown side by side with the exact quoted line.'],
  ['Freshness', 'Source dates and deadlines checked against today’s date.'],
  ['Verify next', 'A prioritized checklist built only from what was actually found.'],
]

export default function Landing() {
  const { loadDemo, busy, error } = useApp()
  const nav = useNavigate()
  return (
    <div>
      <section className="py-12">
        <h1 className="max-w-3xl text-4xl leading-tight sm:text-6xl">Find what’s missing. Verify what matters.</h1>
        <p className="muted mt-4 max-w-2xl text-lg">
          Collect sources about a scholarship, scheme or job. Digital Dark Spot shows what none of them say, where they disagree,
          what may be out of date, and exactly what to check next. It is not a chatbot or a summarizer.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/workspace" className="btn-primary">Start Research</Link>
          <button className="btn-ghost" disabled={busy} onClick={async () => { if (await loadDemo()) nav('/dashboard') }}>
            Try the fictional demo
          </button>
        </div>
        <div className="mt-4 space-y-2">{busy && <Spinner text="Analyzing the demo sources…" />}{error && <ErrorBox>{error}</ErrorBox>}</div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map(([t, d]) => (<div key={t} className="card"><h2 className="text-xl">{t}</h2><p className="muted mt-1 text-sm">{d}</p></div>))}
      </section>
    </div>
  )
}
