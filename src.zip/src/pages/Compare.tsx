import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../store'
import { Empty, StatusBadge } from '../components/ui'
import type { Status } from '../types'

export default function Compare() {
  const { report: r } = useApp()
  const [f, setF] = useState<'all' | Status>('all')
  if (!r) return <Empty text="Run an analysis to compare sources." to="/workspace" cta="Go to Workspace" />
  const rows = r.comparison.filter((x) => f === 'all' || x.status === f)
  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Source comparison</h1>
      <div className="max-w-xs"><label htmlFor="flt">Show</label>
        <select id="flt" value={f} onChange={(e) => setF(e.target.value as typeof f)}>
          <option value="all">All items</option><option value="conflict">Conflicts</option><option value="partial">Coverage gaps</option><option value="missing">Missing everywhere</option><option value="found">Consistent</option>
        </select></div>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead><tr className="text-slate-300"><th className="p-2">Information</th>
            {r.sources.map((s) => <th key={s.id} className="p-2"><Link className="text-teal underline" to={`/sources?open=${s.id}`}>{s.title.split(':')[0]}</Link></th>)}
            <th className="p-2">Status</th></tr></thead>
          <tbody>{rows.map((row) => (
            <tr key={row.key} className="border-t border-navy-700 align-top">
              <td className="p-2 font-medium">{row.label}<div className="text-xs font-normal text-slate-400">{row.category}</div></td>
              {row.cells.map((c) => (
                <td key={c.source_id} className="p-2">
                  {c.value ? <>{c.value}{c.quote && <details><summary className="cursor-pointer text-xs text-teal">Evidence</summary><p className="mt-1 text-xs text-slate-300">“{c.quote}”</p></details>}</>
                    : <span className="text-slate-400">Not listed{c.note ? ` (${c.note.toLowerCase()})` : ''}</span>}
                </td>))}
              <td className="p-2"><StatusBadge s={row.status} /></td>
            </tr>))}</tbody>
        </table>
        {!rows.length && <p className="muted p-3 text-sm">Nothing matches this filter.</p>}
      </div>
    </div>
  )
}
