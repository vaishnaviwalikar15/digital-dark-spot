import { useApp } from '../store'
import { Empty, PRIORITY_COLOR, PRIORITY_TEXT } from '../components/ui'
import { checklistMarkdown, download, slug } from '../util'

export default function Checklist() {
  const { report: r, toggleCheck, draft } = useApp()
  if (!r) return <Empty text="Run an analysis to generate a checklist." to="/workspace" cta="Go to Workspace" />
  const done = r.checklist.filter((c) => c.done).length
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl">Verify next</h1>
        <button className="btn-ghost" onClick={() => download(`${slug(draft.topic || r.question)}-checklist.md`, checklistMarkdown(r), 'text/markdown')}>Download checklist (.md)</button>
      </div>
      <p className="muted">{done} of {r.checklist.length} done. Every item comes from an actual finding.</p>
      {(['high', 'medium', 'low'] as const).map((p) => {
        const items = r.checklist.filter((c) => c.priority === p)
        return items.length ? (
          <section key={p} className="card"><h2 className={`mb-2 text-lg ${PRIORITY_COLOR[p]}`}>{PRIORITY_TEXT[p]}</h2>
            <ul className="space-y-2">{items.map((c) => (
              <li key={c.id}><label className="flex items-start gap-3 font-normal"><input type="checkbox" className="mt-1" checked={c.done} onChange={() => toggleCheck(c.id)} />
                <span className={c.done ? 'text-slate-400 line-through' : ''}>{c.text}</span></label></li>))}</ul></section>
        ) : null
      })}
    </div>
  )
}
