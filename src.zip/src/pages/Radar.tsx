import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar as RadarShape, RadarChart, ResponsiveContainer, Tooltip } from 'recharts'
import { useApp } from '../store'
import { Empty, StatusBadge } from '../components/ui'

export default function Radar() {
  const { report: r } = useApp()
  if (!r) return <Empty text="Run an analysis to see the radar." to="/workspace" cta="Go to Workspace" />
  const data = r.coverage.map((c) => ({ category: c.category, score: Math.round(c.score * 100) }))
  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Information Gap Radar</h1>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card">
          <div role="img" aria-label={`Radar chart of completeness by category. Overall ${r.score} percent.`} className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={data} outerRadius="75%">
                <PolarGrid stroke="#2c4a80" /><PolarAngleAxis dataKey="category" tick={{ fill: '#e2e8f0', fontSize: 12 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <RadarShape dataKey="score" stroke="#2dd4bf" fill="#2dd4bf" fillOpacity={0.35} />
                <Tooltip contentStyle={{ background: '#0a1530', border: '1px solid #2c4a80' }} formatter={(v) => [`${v}%`, 'Coverage']} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-center"><span className="font-display text-4xl text-teal">{r.score}%</span> <span className="muted">overall completeness</span></p>
        </div>
        <div className="space-y-3">
          <div className="card"><h2 className="text-lg">How the score is calculated</h2><p className="muted mt-1 text-sm">{r.score_explanation}</p></div>
          {r.coverage.map((c) => (
            <div key={c.category} className="card flex flex-wrap items-center justify-between gap-2">
              <div><div className="font-medium">{c.category}</div>
                <div className="text-xs text-slate-300">{c.found} found · {c.partial} partial · {c.conflict} conflicting{c.missing ? ' · nothing found' : ''}</div></div>
              <StatusBadge s={c.status} />
            </div>))}
        </div>
      </div>
      <details className="card"><summary className="cursor-pointer text-sm text-teal">Chart data as a table</summary>
        <table className="mt-2 text-sm"><tbody>{data.map((d) => <tr key={d.category}><td className="pr-4">{d.category}</td><td>{d.score}%</td></tr>)}</tbody></table></details>
    </div>
  )
}
