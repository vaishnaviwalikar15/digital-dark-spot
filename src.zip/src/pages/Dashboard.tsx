import { Link } from 'react-router-dom'
import { useApp } from '../store'
import { Empty, Stat } from '../components/ui'
import { FindingCard } from '../components/FindingCard'
import type { Finding } from '../types'

const Section = ({ title, items, note }: { title: string; items: Finding[]; note: string }) => (
  <section className="space-y-3">
    <h2 className="text-2xl">{title} <span className="text-base text-slate-400">({items.length})</span></h2>
    {items.length ? items.map((f) => <FindingCard key={f.id} f={f} />) : <p className="muted card text-sm">{note}</p>}
  </section>
)

export default function Dashboard() {
  const { report: r } = useApp()
  if (!r) return <Empty text="No analysis yet. Add sources and run an analysis." to="/workspace" cta="Go to Workspace" />
  const by = (l: string) => r.findings.filter((f) => f.label === l)
  const e = r.engine
  return (
    <div className="space-y-6">
      <div><h1 className="text-3xl">Analysis dashboard</h1><p className="muted mt-1">{r.question}</p></div>
      <div className={`card text-sm ${e.ai_requested && !e.ai_used ? 'border-amber-400' : ''}`} role="status">
        {e.ai_used ? `Rule-based checks plus Gemini (${e.model}). AI findings are labelled, and their quotes were checked against the sources${e.ai_dropped ? ` (${e.ai_dropped} unverifiable item${e.ai_dropped === 1 ? '' : 's'} discarded)` : ''}.`
          : e.ai_requested ? `AI analysis did not run: ${e.ai_error} Showing rule-based results only.` : 'Rule-based analysis only. No AI model was used for these results.'}
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <Stat value={r.stats.sources} label="Sources analyzed" /><Stat value={r.stats.key_facts} label="Key facts extracted" />
        <Stat value={r.stats.gaps} label="Possible gaps" /><Stat value={r.stats.conflicts} label="Possible conflicts" />
        <Stat value={r.stats.freshness_warnings} label="Freshness warnings" /><Stat value={r.stats.questions} label="Questions to verify" />
      </div>
      <Section title="Possible conflicts" items={by('Possible conflict')} note="No conflicting claims were detected between the sources." />
      <Section title="Information gaps" items={by('Possible information gap')} note="No gaps were detected." />
      <Section title="Needs verification" items={[...by('Needs verification'), ...by('AI-generated suggestion')]} note="Nothing else needs verification." />
      <section className="space-y-3">
        <h2 className="text-2xl">Freshness analysis</h2>
        <div className="card overflow-x-auto"><table className="w-full min-w-[520px] text-left text-sm">
          <thead><tr className="text-slate-300"><th className="p-2">Source</th><th className="p-2">Status</th><th className="p-2">Detail</th></tr></thead>
          <tbody>{r.freshness.map((f, i) => (
            <tr key={i} className="border-t border-navy-700"><td className="p-2"><Link className="text-teal underline" to={`/sources?open=${f.source_id}`}>{f.source_title}</Link></td>
              <td className="p-2">{f.status.replace('_', ' ')}</td><td className="p-2">{f.note}</td></tr>))}</tbody>
        </table></div>
      </section>
      <section className="space-y-3">
        <h2 className="text-2xl">Unanswered questions</h2>
        <div className="card">{r.questions.length ? <ul className="space-y-2">{r.questions.map((q, i) => (
          <li key={i}><span className="font-medium">{q.question}</span> <span className="muted text-sm">({q.reason}{q.origin === 'ai' ? ' Suggested by AI.' : ''})</span></li>))}</ul>
          : <p className="muted text-sm">All six categories have at least some coverage.</p>}</div>
      </section>
      <section className="space-y-3">
        <h2 className="text-2xl">Key information confirmed</h2>
        {by('Confirmed from source').length ? by('Confirmed from source').map((f) => <FindingCard key={f.id} f={f} />) : <p className="muted card text-sm">No facts are stated identically in all sources.</p>}
      </section>
      <div className="flex gap-3 print:hidden"><Link className="btn-primary" to="/checklist">Open the verification checklist</Link><Link className="btn-ghost" to="/report">Export report</Link></div>
    </div>
  )
}
