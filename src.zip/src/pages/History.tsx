import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import { useApp } from '../store'
import { ErrorBox, Spinner } from '../components/ui'
import type { SessionRow } from '../types'

export default function History() {
  const { restore } = useApp()
  const nav = useNavigate()
  const [rows, setRows] = useState<SessionRow[] | null>(null)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { api.sessions().then(setRows).catch((e) => setErr(e instanceof Error ? e.message : 'Could not load history.')) }, [])
  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Analysis history</h1>
      {err && <ErrorBox>{err}</ErrorBox>}
      {!rows && !err && <Spinner text="Loading saved sessions…" />}
      {rows?.length === 0 && <p className="card muted">No saved sessions. Use “Save session” on the Report page.</p>}
      {rows?.map((s) => (
        <div key={s.id} className="card flex flex-wrap items-center justify-between gap-2">
          <div><div className="font-medium">{s.title}</div><div className="text-xs text-slate-300">{s.created_at}</div></div>
          <button className="btn-ghost" onClick={async () => { try { restore((await api.session(s.id)).payload); nav('/dashboard') } catch (e) { setErr(e instanceof Error ? e.message : 'Could not load the session.') } }}>Open</button>
        </div>))}
    </div>
  )
}
