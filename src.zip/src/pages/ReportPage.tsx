import { useState } from 'react'
import { api } from '../api'
import { useApp } from '../store'
import { Empty, ErrorBox } from '../components/ui'
import { FindingCard } from '../components/FindingCard'
import { checklistMarkdown, download, slug } from '../util'

export default function ReportPage() {
  const { report: r, draft, sources } = useApp()
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  if (!r) return <Empty text="Run an analysis to build a report." to="/workspace" cta="Go to Workspace" />
  const name = slug(draft.topic || r.question)
  const save = async () => {
    try { await api.saveSession(draft.topic || r.question.slice(0, 60), { draft, sources, report: r }); setMsg({ ok: true, text: 'Session saved. Find it under History.' }) }
    catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : 'Could not save.' }) }
  }
  const real = r.findings.filter((f) => f.label !== 'Confirmed from source')
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <h1 className="text-3xl">Report</h1>
        <div className="flex flex-wrap gap-2">
          <button className="btn-primary" onClick={() => window.print()}>Export PDF (print)</button>
          <button className="btn-ghost" onClick={() => download(`${name}-report.json`, JSON.stringify(r, null, 2), 'application/json')}>Download JSON</button>
          <button className="btn-ghost" onClick={() => download(`${name}-checklist.md`, checklistMarkdown(r), 'text/markdown')}>Export checklist</button>
          <button className="btn-ghost" onClick={save}>Save session</button>
        </div>
      </div>
      {msg && (msg.ok ? <p role="status" className="text-emerald-300 print:hidden">{msg.text}</p> : <ErrorBox>{msg.text}</ErrorBox>)}
      <h1 className="hidden text-3xl print:block">Digital Dark Spot report</h1>
      <section className="card space-y-1"><h2 className="text-xl">Research question</h2><p>{r.question}</p>
        <p className="muted text-sm">Generated {r.generated_at} · {r.engine.ai_used ? `Rule-based + AI (${r.engine.model})` : 'Rule-based only'} · Completeness {r.score}%</p></section>
      <section className="card"><h2 className="mb-2 text-xl">Sources analyzed</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm">{r.sources.map((s) => <li key={s.id}>{s.title} ({s.origin.replace('_', ' ')}{s.url ? `, ${s.url}` : ''}, retrieved {s.retrieved_at})</li>)}</ul></section>
      <h2 className="text-2xl">Findings and evidence</h2>
      {real.map((f) => <FindingCard key={f.id} f={f} />)}
      <section className="card"><h2 className="mb-2 text-xl">Freshness warnings</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm">{r.freshness.filter((f) => f.status !== 'current').map((f, i) => <li key={i}>{f.source_title}: {f.note}</li>)}</ul></section>
      <section className="card"><h2 className="mb-2 text-xl">Verification checklist</h2>
        <ul className="space-y-1 text-sm">{r.checklist.map((c) => <li key={c.id}>{c.done ? '☑' : '☐'} [{c.priority}] {c.text}</li>)}</ul></section>
      <section className="card"><h2 className="mb-2 text-xl">Uncertainty and limitations</h2><p className="text-sm">{r.limitations}</p></section>
    </div>
  )
}
