import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api, type Extracted } from '../api'
import { useApp } from '../store'
import { ErrorBox, Pill, Spinner } from '../components/ui'

const ORIGIN = { retrieved: 'Retrieved from the web', user_provided: 'Provided by you', demo_fictional: 'Fictional demo data' }

export default function Sources() {
  const { sources, addSources, removeSource } = useApp()
  const [params] = useSearchParams()
  const open = params.get('open')
  const [urls, setUrls] = useState('')
  const [paste, setPaste] = useState({ title: '', url: '', published: '', text: '' })
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [fails, setFails] = useState<Extracted['failures']>([])

  const handle = async (fn: () => Promise<Extracted>) => {
    setBusy(true); setErr(null); setFails([])
    try {
      const r = await fn()
      addSources(r.sources); setFails(r.failures)
      return r.sources.length > 0
    } catch (e) { setErr(e instanceof Error ? e.message : 'Something went wrong.'); return false } finally { setBusy(false) }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Sources</h1>
      {sources.length === 0 && <div className="card muted">No sources yet. Add websites, files or pasted text below, or load the demo from the Workspace.</div>}
      {sources.map((s) => (
        <article key={s.id} id={s.id} className="card space-y-2">
          <div className="flex flex-wrap items-center gap-2"><h2 className="text-lg">{s.title}</h2><Pill>{ORIGIN[s.origin]}</Pill><Pill>{s.source_type.toUpperCase()}</Pill></div>
          <p className="muted text-sm">
            {s.url ? <a className="text-teal underline" href={s.url} target="_blank" rel="noopener noreferrer">{s.url}</a> : 'No URL'}
            {s.domain && ` · ${s.domain}`} · Published: {s.published ?? 'not found'} · Updated: {s.updated ?? 'not found'} · Retrieved {s.retrieved_at.replace('T', ' ')} · {s.text.length.toLocaleString()} characters
          </p>
          <details open={open === s.id}>
            <summary className="cursor-pointer text-sm text-teal">Inspect extracted text</summary>
            <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-navy-950 p-3 text-sm">{s.text.slice(0, 6000)}{s.text.length > 6000 ? '\n… (truncated for display; the full text is analyzed)' : ''}</pre>
          </details>
          <button className="btn-ghost" onClick={() => removeSource(s.id)}>Remove</button>
        </article>
      ))}

      <div className="card space-y-3">
        <h2 className="text-xl">Add sources</h2>
        <div>
          <label htmlFor="urls">Website URLs, one per line</label>
          <textarea id="urls" rows={3} value={urls} onChange={(e) => setUrls(e.target.value)} placeholder="https://example.org/scholarship" />
          <button className="btn-primary mt-2" disabled={busy || !urls.trim()} onClick={async () => { if (await handle(() => api.urls(urls.split('\n').map((u) => u.trim()).filter(Boolean)))) setUrls('') }}>Fetch websites</button>
        </div>
        <div>
          <label htmlFor="files">PDF, DOCX or TXT files</label>
          <input id="files" type="file" multiple accept=".pdf,.docx,.txt,.md" onChange={(e) => { const f = Array.from(e.target.files ?? []); if (f.length) handle(() => api.files(f)); e.target.value = '' }} />
        </div>
        <form onSubmit={async (e) => {
          e.preventDefault(); setBusy(true); setErr(null); setFails([])
          try { const r = await api.paste({ ...paste, url: paste.url || undefined, published: paste.published || undefined }); addSources([r.source]); setPaste({ title: '', url: '', published: '', text: '' }) }
          catch (x) { setErr(x instanceof Error ? x.message : 'Could not add the text.') } finally { setBusy(false) }
        }}>
          <label htmlFor="pt">Paste text</label>
          <div className="grid gap-2 sm:grid-cols-3">
            <input aria-label="Title" placeholder="Title" value={paste.title} onChange={(e) => setPaste({ ...paste, title: e.target.value })} />
            <input aria-label="Original URL (optional)" placeholder="Original URL (optional)" value={paste.url} onChange={(e) => setPaste({ ...paste, url: e.target.value })} />
            <input aria-label="Published or updated date (optional)" placeholder="Date, e.g. 3 March 2026 (optional)" value={paste.published} onChange={(e) => setPaste({ ...paste, published: e.target.value })} />
          </div>
          <textarea id="pt" rows={5} required className="mt-2" value={paste.text} onChange={(e) => setPaste({ ...paste, text: e.target.value })} />
          <button className="btn-primary mt-2" disabled={busy || !paste.text.trim()}>Add pasted text</button>
          <p className="muted mt-1 text-xs">Pasted text is marked as provided by you. The URL is only a reference and is not fetched.</p>
        </form>
        {busy && <Spinner text="Extracting text…" />}
        {err && <ErrorBox>{err}</ErrorBox>}
        {fails.length > 0 && (
          <ErrorBox><p className="font-semibold">These could not be retrieved and were not added:</p>
            <ul className="list-disc pl-5">{fails.map((f, i) => <li key={i}>{f.url}: {f.error}</li>)}</ul></ErrorBox>
        )}
      </div>
    </div>
  )
}
