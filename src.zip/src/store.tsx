import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api } from './api'
import type { Draft, Health, Report, Source } from './types'

const EMPTY: Draft = { topic: '', question: '', subquestions: '', category: 'General Research' }

interface Ctx {
  draft: Draft; setDraft: (d: Draft) => void
  sources: Source[]; addSources: (s: Source[]) => void; removeSource: (id: string) => void
  report: Report | null; stale: boolean; busy: boolean; error: string | null; notice: string | null
  health: Health | null
  analyze: (useAi: boolean) => Promise<boolean>
  loadDemo: () => Promise<boolean>
  toggleCheck: (id: string) => void
  restore: (p: { draft: Draft; sources: Source[]; report: Report }) => void
}
const C = createContext<Ctx | null>(null)
export const useApp = () => {
  const c = useContext(C)
  if (!c) throw new Error('useApp must be used inside AppProvider')
  return c
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [draft, setDraft] = useState<Draft>(EMPTY)
  const [sources, setSources] = useState<Source[]>([])
  const [report, setReport] = useState<Report | null>(null)
  const [stale, setStale] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [health, setHealth] = useState<Health | null>(null)

  useEffect(() => { api.health().then(setHealth).catch(() => setHealth(null)) }, [])

  const run = useCallback(async (d: Draft, s: Source[], useAi: boolean) => {
    setBusy(true); setError(null)
    try {
      setReport(await api.analyze(d, s, useAi)); setStale(false)
      return true
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Analysis failed.')
      return false
    } finally { setBusy(false) }
  }, [])

  const value = useMemo<Ctx>(() => ({
    draft, setDraft, sources, report, stale, busy, error, notice, health,
    addSources: (s) => { setSources((p) => [...p, ...s]); setStale(true) },
    removeSource: (id) => { setSources((p) => p.filter((x) => x.id !== id)); setStale(true) },
    analyze: (useAi) => run(draft, sources, useAi),
    loadDemo: async () => {
      try {
        const d = await api.demo()
        const nd: Draft = { topic: d.topic, question: d.question, category: d.category, subquestions: '' }
        setDraft(nd); setSources(d.sources); setNotice(d.notice)
        return run(nd, d.sources, false)
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Could not load the demo.')
        return false
      }
    },
    toggleCheck: (id) => setReport((r) => r && { ...r, checklist: r.checklist.map((c) => (c.id === id ? { ...c, done: !c.done } : c)) }),
    restore: (p) => { setDraft(p.draft); setSources(p.sources); setReport(p.report); setStale(false); setNotice(null) },
  }), [draft, sources, report, stale, busy, error, notice, health, run])

  return <C.Provider value={value}>{children}</C.Provider>
}
