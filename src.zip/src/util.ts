import type { Report } from './types'

export function download(name: string, content: string, mime: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }))
  const a = document.createElement('a')
  a.href = url
  a.download = name
  a.click()
  URL.revokeObjectURL(url)
}
export const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'research'

export function checklistMarkdown(r: Report): string {
  const lines = [`# Verification checklist`, ``, `Question: ${r.question}`, ``]
  for (const p of ['high', 'medium', 'low'] as const) {
    const items = r.checklist.filter((c) => c.priority === p)
    if (!items.length) continue
    lines.push(`## ${p[0].toUpperCase() + p.slice(1)} priority`, ...items.map((c) => `- [${c.done ? 'x' : ' '}] ${c.text}`), '')
  }
  return lines.join('\n')
}
